const express = require('express');
const router = express.Router();
const { categories } = require('../data/dummyData');  // Importing the dummy data

// Get all categories
router.get('/', (req, res) => {
    res.json(categories);
});

// Get a category by ID
router.get('/:id', (req, res) => {
    const category = categories.find(c => c.id === parseInt(req.params.id));
    category ? res.json(category) : res.status(404).json({ message: 'Category not found' });
});

// Create a new category
router.post('/', (req, res) => {
    const newCategory = { id: categories.length + 1, ...req.body };  // Adding a new category with id incremented
    categories.push(newCategory);
    res.status(201).json(newCategory);
});

// Update a category
router.put('/:id', (req, res) => {
    const index = categories.findIndex(c => c.id === parseInt(req.params.id));
    if (index === -1) return res.status(404).json({ message: 'Category not found' });

    categories[index] = { id: parseInt(req.params.id), ...req.body };
    res.json(categories[index]);
});

// Delete a category
router.delete('/:id', (req, res) => {
    const index = categories.findIndex(c => c.id === parseInt(req.params.id));
    if (index === -1) return res.status(404).json({ message: 'Category not found' });

    const deletedCategory = categories.splice(index, 1);
    res.json(deletedCategory);
});

module.exports = router;
