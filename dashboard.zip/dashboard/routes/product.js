// routes/product.js
const express = require('express');
const router = express.Router();
const { products } = require('../data/dummyData');  // Importing the dummy data

// Get all products
router.get('/', (req, res) => {
    res.json(products);
});

// Get a product by ID
router.get('/:id', (req, res) => {
    const product = products.find(p => p.id === parseInt(req.params.id));
    product ? res.json(product) : res.status(404).json({ message: 'Product not found' });
});

// Create a new product
router.post('/', (req, res) => {
    const newProduct = { id: products.length + 1, ...req.body };
    products.push(newProduct);
    res.status(201).json(newProduct);
});

// Update a product
router.put('/:id', (req, res) => {
    const index = products.findIndex(p => p.id === parseInt(req.params.id));
    if (index === -1) return res.status(404).json({ message: 'Product not found' });

    products[index] = { id: parseInt(req.params.id), ...req.body };
    res.json(products[index]);
});

// Delete a product
router.delete('/:id', (req, res) => {
    const index = products.findIndex(p => p.id === parseInt(req.params.id));
    if (index === -1) return res.status(404).json({ message: 'Product not found' });

    const deletedProduct = products.splice(index, 1);
    res.json(deletedProduct);
});

module.exports = router;
