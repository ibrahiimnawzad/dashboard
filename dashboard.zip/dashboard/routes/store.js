const express = require('express');
const router = express.Router();
const { stores } = require('../data/dummyData');  // Importing the dummy data

// Get all stores
router.get('/', (req, res) => {
    res.json(stores);
});

// Get a store by ID
router.get('/:id', (req, res) => {
    const store = stores.find(s => s.id === parseInt(req.params.id));
    store ? res.json(store) : res.status(404).json({ message: 'Store not found' });
});

// Create a new store
router.post('/', (req, res) => {
    const newStore = { id: stores.length + 1, ...req.body };  // Adding a new store with id incremented
    stores.push(newStore);
    res.status(201).json(newStore);
});

// Update a store
router.put('/:id', (req, res) => {
    const index = stores.findIndex(s => s.id === parseInt(req.params.id));
    if (index === -1) return res.status(404).json({ message: 'Store not found' });

    stores[index] = { id: parseInt(req.params.id), ...req.body };
    res.json(stores[index]);
});

// Delete a store
router.delete('/:id', (req, res) => {
    const index = stores.findIndex(s => s.id === parseInt(req.params.id));
    if (index === -1) return res.status(404).json({ message: 'Store not found' });

    const deletedStore = stores.splice(index, 1);
    res.json(deletedStore);
});

module.exports = router;
